"""Command registry - Placeholder for command management

The Click-based CLI in index.py handles command registration directly.
This file is kept for API compatibility but is not actively used.
"""

# Commands are registered in cli/index.py using Click decorators
