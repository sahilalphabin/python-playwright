"""
TestDino CLI - CLI tool for uploading Playwright test reports to TestDino platform
"""

from testdino_cli.version import VERSION

__version__ = VERSION
__all__ = ["__version__"]
